﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.Networking; 


public class Spin : MonoBehaviour
{       
        private string url = "http://localhost:8080/api/models";
        public float speed = 10.0f;
        private List<RootModel.Datum> models;
        private int count = 0;

    // Start is called before the first frame update
    void Start()
    {   
        InvokeRepeating("Change",1.0f,1.0f);
        Debug.Log("Start");
        StartCoroutine(GetRequest(url));
    }

    // Update is called once per frame
    void Update()
    {
        
        transform.Rotate(Vector3.up, speed * Time.deltaTime);
    }

    void Change(){
        var datum = models[count];
        gameObject.GetComponent<Renderer>().material.color = new Color32(datum.r,datum.g,datum.b,0);
        speed = datum.speed;
        transform.Rotate(datum.x,datum.y, datum.z, Space.Self);
        count++;
        if(count == models.Count){
            count = 0;
        }
    }

     IEnumerator GetRequest(string uri)
    {    
        using (UnityWebRequest webRequest = UnityWebRequest.Get(uri))
        {
            // Request and wait for the desired page.
            yield return webRequest.SendWebRequest();


            if (webRequest.isNetworkError)
            {
                Debug.Log(webRequest.error);
            }
            else
            {

                models = RootModel.createFromJson(webRequest.downloadHandler.text).data; 

            }
        }
    }

}

[System.Serializable]
public class RootModel
{
    public string status ;
    public string message ;
    public List<Datum> data;

[System.Serializable]
public class Datum
{
    public string _id ;
    public int x ;
    public int y ;
    public int z ;
    public byte r ;
    public byte b ;
    public byte g ;
    public float speed ;
    public int __v ;
}

     public static  RootModel createFromJson(string json){
       return JsonUtility.FromJson<RootModel>(json);
    } 
}