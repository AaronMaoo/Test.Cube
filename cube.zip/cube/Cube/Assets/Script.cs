﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.Networking; 


public class Script : MonoBehaviour
{       
        private string url = "http://localhost:8080/api/models";
        public int x;
        public int y;
        public int z;
        public int r;
        public int g;
        public int b;
        public float speed = 10.0f;
    // Start is called before the first frame update
    void Start()
    {
        gameObject.GetComponent<Renderer>().material.color = new Color32(66, 134, 244,0);
        GetRequest(url);
    }

    // Update is called once per frame
    void Update()
    {
        InvokeRepeating("Change",1.0f,1.0f);
        transform.Rotate(Vector3.up, speed * Time.deltaTime);
    }

    void Change(){
         // Sample JSON for the following script has attached     
         GetRequest(url);
    }

     IEnumerator GetRequest(string uri)
    {
        using (UnityWebRequest webRequest = UnityWebRequest.Get(uri))
        {
            // Request and wait for the desired page.
            yield return webRequest.SendWebRequest();


            if (webRequest.isNetworkError)
            {
                Debug.Log(": Error: " + webRequest.error);
            }
            else
            {
                Debug.Log(":\nReceived: " + webRequest.downloadHandler.text);
            }
        }
    }

}

[System.Serializable]
public class Data{
    public string status;
    public string message;
    public List<Model> models;

    [System.Serializable]
    public class Model{
        public string _id;
        public int x;
        public int y;
        public int z;
        public int r;
        public int g;
        public int b;
        public float speed;
        public int __v;
    } 

    public static Data createFromJson(string json){
       return JsonUtility.FromJson<Data>(json);
    } 
}