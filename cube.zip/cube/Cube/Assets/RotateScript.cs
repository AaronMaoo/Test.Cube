﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateScript : MonoBehaviour
{    
    
    public float speed = 10f;
    public int x = 0;
    public int y = 0;
    public int z = 0;
    public int r = 0;
    public int g = 0;
    public int b = 0;
    
    private int one = 1;

    // Start is called before the first frame update
    void Start()
    {
      // gameObject.renderer.material.color = new Color(233, 79, 55);
    }

    // // Update is called once per frame
    void Update()
    {    
        InvokeRepeating("Change", 0.0f, 1.0f);
        transform.Rotate(Vector3.up, speed * Time.deltaTime);  
    }

    void Change(){
         if(one == 1){
               gameObject.GetComponent<Renderer>().material.color = new Color(123, 179, 55);
               one = 0;
           }else{
               gameObject.GetComponent<Renderer>().material.color = new Color(233, 79, 55);
               one = 1;
           }
         gameObject.GetComponent<Renderer>().material.color = new Color(233, 79, 55);  
    }
}
