// Import model model
Model = require('./Model');
// Handle index actions
exports.index = function (req, res) {
    Model.get(function (err, models) {
        if (err) {
            res.json({
                status: "error",
                message: err,
            });
        }
        res.json({
            status: "success",
            message: "Models retrieved successfully",
            data: models
        });
    });
};
// Handle create model actions
exports.new = function (req, res) {
    var model = new Model();
    console.log(req.body)
    model.x = req.body.x
    model.y = req.body.y
    model.z = req.body.z  
    model.r = req.body.r
    model.b = req.body.b
    model.g = req.body.g
    model.speed = req.body.speed
    // save the model and check for errors
    model.save(function (err) {
        if (err)
            res.json(err);
        res.json({
            message: 'New model created!',
            data: model
        });
    });
};


// Handle update model info
exports.update = function (req, res) {
    Model.findById(req.params.model_id, function (err, model) {
   
    if (err)
        res.send(err);
    model.x = req.body.x
    model.y = req.body.y
    model.z = req.body.z  
    model.r = req.body.r
    model.b = req.body.b
    model.g = req.body.g
    model.speed = req.body.speed 
    // save the model and check for errors
    model.save(function (err) {
    if (err)
        res.json(err);
    res.json({
        message: 'Model Info updated',
        data: model
    });
    });
  });
};


// Handle delete model
exports.delete = function (req, res) {
Model.remove({
    _id: req.params.model_id
  }, function (err, model) {
    if (err){
        res.send(err);
    }else{
        res.json({
            status: "success",
            message: 'Model deleted'
        });
    }
 });
};