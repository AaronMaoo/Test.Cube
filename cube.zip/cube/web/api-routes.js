let cors = require('cors')
// Initialize express router
let router = require('express').Router();
// Import model controller
var contoller = require('./ModelController');

router.use(cors());

// Set default API response
router.get('/',function (req, res) {
    res.json({
        status: 'API Its Working',
        message: 'Welcome to Cube ApI!',
    });
});

// model routes
router.route('/models')
    .get(contoller.index)
    .post(contoller.new);
router.route('/models/:model_id')
    .put(contoller.update)
    .delete(contoller.delete)
// Export API routes
module.exports = router;