var app = new Vue({
    el: '#app',
    data: {
      models : [],
      save : true,
      editId : 0 ,
      idPut:0
    },
    methods : {
      del(id){
         axios.delete("http://localhost:8080/api/models/"+this.models[id]._id).then(res =>{
            document.getElementById(id).remove();
         }).catch(err=>{
            console.log(err);
         })
       },
       edit(id){
         var model = this.models[id];
         document.querySelector("#x").value = model.x; 
         document.querySelector("#y").value = model.y;
         document.querySelector("#z").value = model.z;
         document.querySelector("#r").value = model.r;
         document.querySelector("#g").value = model.g;
         document.querySelector("#b").value = model.b;
         document.querySelector("#speed").value = model.speed;
         document.getElementById(id).remove();
         this.editId = model._id;
         this.save = false;
         this.idPut = id;
       },
       getValues(){
          axios.get("http://localhost:8080/api/models").then(res =>{
             this.models = res.data.data;
          }).catch(err =>{
            console.log(err)
          })
       },
       sendData(event){
         event.preventDefault()
         var model = {
            x: document.querySelector("#x").value,
            y:document.querySelector("#y").value,
            z:document.querySelector("#z").value,
            r:document.querySelector("#r").value,
            g:document.querySelector("#g").value,
            b:document.querySelector("#b").value,
            speed:document.querySelector("#speed").value
         }
         if(this.save){
            axios.post("http://localhost:8080/api/models",model)
            this.models.push(model)
         }else{
            this.save = true;
            axios.put("http://localhost:8080/api/models/"+this.editId,model).then(res=>{
                this.models.push(model)
            
            }).catch(err=>{
               console.log(err);
            })
         }     
             this.clearInput()
       }
       ,
       clearInput(){
         document.querySelector("#x").value = ""; 
         document.querySelector("#y").value = "";
         document.querySelector("#z").value = "";
         document.querySelector("#r").value = "";
         document.querySelector("#g").value = "";
         document.querySelector("#b").value = "";
         document.querySelector("#speed").value = "";
       }
    },
    beforeMount(){
        this.getValues()
     },
  })