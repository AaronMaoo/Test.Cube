let express = require('express')
// Import Mongoose
let mongoose = require('mongoose')
// Import Body parser
let bodyParser = require('body-parser')

let cors = require('cors')

var ejs = require('ejs');

// Initialize the app
let app = express()
// Setup server port
var port = process.env.PORT || 8080;

app.use(cors()) 
// Import routes
let apiRoutes = require("./api-routes")

app.get('/', (req, res) => {
     res.render('index.ejs')
});

// Send message for default URL
// Configure bodyparser to handle post requests
app.use(bodyParser.urlencoded({
     extended: true
}));
  
app.use(bodyParser.json());
app.use(express.static('static'));
app.set('view engine', 'ejs');
app.set('views', './views');

// Use Api routes in the App
app.use('/api', apiRoutes)

// Connect to Mongoose and set connection variable
mongoose.connect('mongodb://localhost/cube')
var db = mongoose.connection

// Launch app to listen to specified port
app.listen(port, function () {
     console.log("Running Cube on port " + port);
});




