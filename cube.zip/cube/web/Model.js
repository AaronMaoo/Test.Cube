var mongoose = require('mongoose');
// Setup schema
var modelSchema = mongoose.Schema({
    x: {
        type: Number,
        required: true
    },
    y: {
        type: Number,
        required: true
    },
    z: {
        type: Number,
        required: true
    },
    r: {
        type: Number,
        required: true
    },
    g: {
        type: Number,
        required: true
    },
    b: {
        type: Number,
        required: true
    },
    speed: {
       type : Number,
       required : true
    }   
});
// Export Contact model
var Model = module.exports = mongoose.model('model', modelSchema);
module.exports.get = function (callback, limit) {
    Model.find(callback).limit(limit);
}